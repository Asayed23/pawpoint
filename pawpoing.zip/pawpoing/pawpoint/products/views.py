from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import product
from django.core import serializers
from django.http import JsonResponse
import json
# Create your views here.
class product_list_api(APIView):
    # permission_classes = ()  # <-- And here

    def get(self, request):
        queryset=product.objects.all()
        print(queryset)
        # assuming obj is a model instance
        SomeModel_json = serializers.serialize("json", product.objects.all())
        struct = json.loads(SomeModel_json)
        data = {"SomeModel_json": struct}
        return JsonResponse(data)



class product_detail_api(APIView):
    # permission_classes = ()  # <-- And here

    def get(self, request,pk=None, *args, **kwargs):
        queryset=product.objects.filter(pk=pk)
        print(queryset)
        # assuming obj is a model instance
        SomeModel_json = serializers.serialize("json", product.objects.filter(pk=pk))
        struct = json.loads(SomeModel_json)
        data = {"SomeModel_json": struct}
        return JsonResponse(data)