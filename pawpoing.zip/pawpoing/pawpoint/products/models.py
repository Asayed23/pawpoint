from django.db import models

# Create your models here.
class product(models.Model):

    title = models.CharField(null=True, blank=True, max_length=100)
    make = models.CharField(null=True, blank=True, max_length=100)
    item_number=models.IntegerField(blank=True, unique=True,null=True)
    weight=models.FloatField(default=False,null=True)
    made_in=models.CharField(null=True, blank=True, max_length=100)
    description = models.TextField(blank=True, default=None)
    quantity = models.IntegerField(blank=True, )
    price = models.FloatField(null=True)

    image = models.FileField(upload_to="./static/product_image/", null=True, blank=True)



    discount=models.FloatField(default=False,blank=True,null=True)

    best_selling=models.BooleanField(default=False)

    limited_offer=models.BooleanField(default=False)

    pet_type=models.CharField(blank=True, max_length=10, default=None)

    categoury=models.CharField(null=True, blank=True, max_length=100)

    related_products=models.CharField(null=True, blank=True, max_length=100)
    def __str__(self):
        return self.title


class productImage(models.Model):
    product = models.ForeignKey(product, default=None, on_delete=models.CASCADE)
    images = models.FileField(upload_to='images/')

    def __str__(self):
        return self.product.title