from django.db import models
from django.contrib.auth.models import User
# Create your views here.
class UserProfile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    full_name = models.CharField(null=True, blank=False, max_length=100)
    phone_number = models.IntegerField(blank=False, unique=True)
    admin = models.CharField(null=True, blank=False, max_length=100)  # admin
    address=models.CharField(null=True, blank=False, max_length=100)


    favourite = models.CharField(null=True, blank=False, max_length=100)


