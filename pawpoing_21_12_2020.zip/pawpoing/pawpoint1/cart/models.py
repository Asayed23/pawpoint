from django.db import models
from products.models import product
# Create your models here.




class cart(models.Model):
    # pass
    # cart=models.ManyToManyField(cartitem,null=True)
    totalprice = models.FloatField(null=True)
    order_status = models.CharField(null=True, blank=True, max_length=100)
    order_number=models.CharField(null=True, blank=True, max_length=100)
    shippingaddress=models.CharField(null=True, blank=True, max_length=100)

class cartitem(models.Model):
    quantity = models.IntegerField(blank=True, )
    price = models.FloatField(null=True)
    CartId = models.ForeignKey(cart, on_delete=models.CASCADE, null=True)
    productid=models.ForeignKey(product, on_delete=models.CASCADE, null=True)

class favourite(models.Model):
    # pass
    favourite=models.ManyToManyField(product,null=True)
    # # cart_name = models.CharField(null=True, blank=True, max_length=100)
    # cart_user=models.CharField(null=True, blank=True, max_length=100)

class order(models.Model):

    payment_id = models.CharField(null=True, blank=True, max_length=100)
    CartId = models.ForeignKey(cart, on_delete=models.CASCADE, null=True)
    CustomerID=models.ForeignKey(product, on_delete=models.CASCADE, null=True)


