from django.contrib import admin
from .models import cart,favourite,cartitem

@admin.register(cart)
class cartAdmin(admin.ModelAdmin):
    pass


@admin.register(favourite)
class favouriteAdmin(admin.ModelAdmin):
    pass
@admin.register(cartitem)
class cartitemAdmin(admin.ModelAdmin):
    pass