from django.contrib import admin

# Register your models here.


from .models import product, productImage


class productImageAdmin(admin.StackedInline):
    model = productImage


@admin.register(product)
class productdmin(admin.ModelAdmin):
    inlines = [productImageAdmin]

    class Meta:
        model = product


@admin.register(productImage)
class productImageAdmin(admin.ModelAdmin):
    pass