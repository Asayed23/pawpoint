from rest_framework import serializers
from .models import product

# User Serializer
class productSerializer(serializers.ModelSerializer):
    class Meta:
        model = product
        fields = ('id', 'title', 'make','item_number', 'weight', 'made_in','description', 'quantity', 'price','image')

# # Register Serializer
# class RegisterSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = User
#         fields = ('id', 'username', 'email', 'password')
#         extra_kwargs = {'password': {'write_only': True}}
#
#     def create(self, validated_data):
#         user = User.objects.create_user(validated_data['username'], validated_data['email'], validated_data['password'])
#
#         return user