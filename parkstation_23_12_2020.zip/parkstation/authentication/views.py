from django.shortcuts import render

# Create your views here.
from rest_framework import generics, permissions
from rest_framework.response import Response
from knox.models import AuthToken
from .serializers import UserSerializer, RegisterSerializer
from .models import UserProfile
import base64
from django.core.files.base import ContentFile
from django.contrib.auth.models import User
from rest_framework import status


# Register API
class RegisterAPI(generics.GenericAPIView):
    serializer_class = RegisterSerializer

    http_method_names = ['get', 'post', 'head', 'put']
    serializer_class = RegisterSerializer

    def get(self, request, *args, **kwargs):
        return Response({
            "vehicle_type_list": ['Sedan', 'SUV', 'VAN', 'Pickup']
        })

    def post(self, request, *args, **kwargs):

        if 'email' in request.data and  User.objects.filter(

                email=request.data['email']).exists():

            return Response({"errorCode": 6001}, status=status.HTTP_400_BAD_REQUEST)
        if 'username' in request.data and  User.objects.filter(

                username=request.data['username']).exists():

            return Response({"errorCode": 6001}, status=status.HTTP_400_BAD_REQUEST)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user_profile = UserProfile()

        if 'phone_number' in request.data and not UserProfile.objects.filter(

                phone_number=request.data['phone_number']).exists():
            user = serializer.save()
            print("hello")
            user_profile.user = user
            user_profile.phone_number = request.data['phone_number']
            user_profile.full_name = request.data['full_name']

            # home_location
            user_profile.Home_city = request.data['Home_city']
            user_profile.Home_country = request.data['Home_country']
            user_profile.Home_latitude = request.data['Home_latitude']
            user_profile.Home_longitude = request.data['Home_longitude']
            user_profile.Home_neighbourhood = request.data['Home_neighbourhood']
            user_profile.Home_street = request.data['Home_street']
            # work location
            user_profile.Work_city = request.data['Work_city']
            user_profile.Work_country = request.data['Work_country']
            user_profile.Work_latitude = request.data['Work_latitude']
            user_profile.Work_longitude = request.data['Work_longitude']
            user_profile.Work_neighbourhood = request.data['Work_neighbourhood']
            user_profile.Work_street = request.data['Work_street']

            user_profile.vehicle_types = request.data['vehicle_types']
            user_profile.Account_type = request.data["Account_type"]
            user_profile.phone_code = request.data["phone_code"]

            if 'image' in request.data:
                # image_data = request.data['image']
                imgstr = request.data['image']
                # format, imgstr = image_data.split(';base64,')
                # print("format", format)
                # ext = format.split('/')[-1]

                data = ContentFile(base64.b64decode(imgstr))
                file_name = "../static/userprofile_photo/myphoto.jpg"
                user_profile.image.save(file_name, data, save=True)  # image is User's model field

            user_profile.save()
            user_response=UserSerializer(user, context=self.get_serializer_context()).data
            user_profile_response=UserProfile.objects.get(user=user_response['id'])
            print(user_profile_response)
            return Response({
                "id": user_response['id'],
                "username": user_response['username'],
                "email": user_response['email'],

                "phone_code": user_profile_response.phone_code,
                "phone_number": user_profile_response.phone_number,
                "full_name": user_profile_response.full_name,
                # home_location
                "Home_city": user_profile_response.Home_city,
                "Home_country": user_profile_response.Home_country,
                "Home_latitude": user_profile_response.Home_latitude,
                "Home_longitude": user_profile_response.Home_longitude,
                "Home_neighbourhood": user_profile_response.Home_neighbourhood,
                "Home_street": user_profile_response.Home_street,
                # work location
                "Work_city": user_profile_response.Work_city,
                "Work_country": user_profile_response.Work_country,
                "Work_latitude": user_profile_response.Work_latitude,
                "Work_longitude": user_profile_response.Work_longitude,
                "Work_neighbourhood": user_profile_response.Work_neighbourhood,
                "Work_street": user_profile_response.Work_street,

                "vehicle_types": user_profile_response.vehicle_types,
                "Account_type": user_profile_response.Account_type,

                'image': user_profile_response.image.url,

                "token": AuthToken.objects.create(user)[1],
            })


        else:
            return Response({"errorCode": 6002}, status=status.HTTP_400_BAD_REQUEST)






        return Response({"errorCode":6003}, status=status.HTTP_400_BAD_REQUEST)





from django.contrib.auth import login,authenticate

from rest_framework import permissions
from rest_framework.authtoken.serializers import AuthTokenSerializer
from knox.views import LoginView as KnoxLoginView
from django.contrib.auth import get_user_model

class LoginAPI(KnoxLoginView):
    permission_classes = (permissions.AllowAny,)

    def post(self, request, format=None):
        serializer = AuthTokenSerializer(data=request.data)

        if 'password' in request.data and 'username' in request.data:
            user1 = authenticate(request, username=request.data['username'], password=request.data['password'])
        else:
            return Response({"errorCode": 401}, status=status.HTTP_401_UNAUTHORIZED)
        if user1 is not None:
            serializer.is_valid(raise_exception=True)

            user = serializer.validated_data['user']

            login(request, user)
            User = get_user_model()
            user_response=User.objects.filter(username=request.data['username'])
            print(user_response)
            user_profile_response = UserProfile.objects.get(user=request.user.id)
            return Response({
                "id": request.user.id,
                "username": request.user.username,
                "email": request.user.email,

                "phone_code": user_profile_response.phone_code,
                "phone_number": user_profile_response.phone_number,
                "full_name": user_profile_response.full_name,
                # home_location
                "Home_city": user_profile_response.Home_city,
                "Home_country": user_profile_response.Home_country,
                "Home_latitude": user_profile_response.Home_latitude,
                "Home_longitude": user_profile_response.Home_longitude,
                "Home_neighbourhood": user_profile_response.Home_neighbourhood,
                "Home_street": user_profile_response.Home_street,
                # work location
                "Work_city": user_profile_response.Work_city,
                "Work_country": user_profile_response.Work_country,
                "Work_latitude": user_profile_response.Work_latitude,
                "Work_longitude": user_profile_response.Work_longitude,
                "Work_neighbourhood": user_profile_response.Work_neighbourhood,
                "Work_street": user_profile_response.Work_street,

                "vehicle_types": user_profile_response.vehicle_types,
                "Account_type": user_profile_response.Account_type,

                'image': user_profile_response.image.url,

                "token": AuthToken.objects.create(user)[1],
            })
        else:
            return Response({"errorCode": 6000}, status=status.HTTP_400_BAD_REQUEST)

        return super(LoginAPI, self).post(request, format=None)




class parkingAPI(generics.GenericAPIView):

    serializer_class = RegisterSerializer

    http_method_names = ['get', 'post', 'head', 'put']
    serializer_class = RegisterSerializer


    def post(self, request, *args, **kwargs):
        context = []
        if 'current_lon' in request.data and 'current_lat' in request.data:

            current_location={"lon":float(request.data['current_lon']),"lat":float(request.data['current_lat']),"type":'current'}
            first_location={"lon":float(request.data['current_lon'])+.1,"lat":float(request.data['current_lat'])+.1,"type":'AI'}
            second_location = {"lon":float(request.data['current_lon']) ,"lat": float(request.data['current_lat']) + .1,"type": 'busy'}
            third_location = {"lon":float(request.data['current_lon']) + .1,"lat": float(request.data['current_lat']) ,"type": 'available'}
            forth_location = {"lon":float(request.data['current_lon']) + .2,"lat": float(request.data['current_lat']) + .1,"type": 'streaming'}
            # context.append({'Current_location':current_location})
            # context.append({'first_location': first_location})
            # context.append({'second_location':second_location})
            # context.append({'third_location': third_location})
            # context.append({'forth_location': forth_location})

            context.append(current_location)
            context.append( first_location)
            context.append(second_location)
            context.append( third_location)
            context.append( forth_location)

            return Response(context)
        return Response(context)