from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class UserProfile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    full_name = models.CharField(null=True,blank=False,max_length=100)
    phone_code= models.CharField(blank=True,max_length=10,default=None)
    phone_number = models.IntegerField(blank=False,unique=True)
    #Home Location
    Home_latitude = models.FloatField(null=True, default=None, verbose_name="Home location latitude")
    Home_longitude = models.FloatField(null=True, default=None, verbose_name="Home location longitude")
    Home_street = models.CharField(null=True,max_length=100, verbose_name="Home street")
    Home_neighbourhood  = models.CharField(null=True,max_length=100,default="", verbose_name="Home neighbourhood")
    Home_zip_code = models.CharField(null=True,max_length=100, verbose_name="Home zip code")
    Home_city = models.CharField(null=True,max_length=100, verbose_name="Home city")
    Home_country = models.CharField(null=True,max_length=100, verbose_name="Home country")
    # Work Location
    Work_latitude = models.FloatField(null=True, default=None, verbose_name="Work location latitude")
    Work_longitude = models.FloatField(null=True, default=None, verbose_name="Work location longitude")
    Work_street = models.CharField(null=True,max_length=100, verbose_name="Work street")
    Work_neighbourhood = models.CharField(null=True,max_length=100,default="", verbose_name="Work neighbourhood")
    Work_zip_code = models.CharField(null=True,max_length=100, verbose_name="Work zip code")
    Work_city = models.CharField(null=True,max_length=100, verbose_name="Work city")
    Work_country = models.CharField(null=True,max_length=100, verbose_name="Work country")

    Account_type = models.CharField(null=True,blank=False,max_length=30)
    Active_Account=models.CharField(null=True,blank=False,max_length=30,default="driver")

    vehicle_types = models.CharField(null=True,blank=False,max_length=30)
    admin = models.BooleanField(default=False)  # admin
    image = models.FileField(upload_to='authentication/', null=True, blank=True)

