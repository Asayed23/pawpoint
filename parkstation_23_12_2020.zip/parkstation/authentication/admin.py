from django.contrib import admin
from .models import UserProfile

class UserProfile_admin(admin.ModelAdmin):
    list_display = ['__str__','full_name','phone_number']
    class Meta:
        model=UserProfile
admin.site.register(UserProfile)
# Register your models here.
