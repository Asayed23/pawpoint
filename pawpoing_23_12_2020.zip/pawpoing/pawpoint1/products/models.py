from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class product(models.Model):

    name = models.CharField(null=True, blank=True, max_length=100)
    brand = models.CharField(null=True, blank=True, max_length=100)
    productID=models.CharField(null=True, blank=True, max_length=100)
    weight=models.FloatField(default=False,null=True)
    made_in=models.CharField(null=True, blank=True, max_length=100)
    desc = models.TextField(null=True, blank=True, max_length=2000)
    moreDesc = models.TextField(null=True, blank=True, max_length=2000)
    foodType=models.CharField(null=True, blank=True, max_length=100)
    lifeStage=models.CharField(null=True, blank=True, max_length=100)
    flavor=models.CharField(null=True, blank=True, max_length=100)
    ingredients=models.TextField(null=True, blank=True, max_length=2000)
    directions=models.TextField(null=True, blank=True, max_length=2000)
    size=models.CharField(null=True, blank=True, max_length=100)
    pet=models.CharField(null=True, blank=True, max_length=100)
    category=models.CharField(null=True, blank=True, max_length=100)
    subCategory=models.CharField(null=True, blank=True, max_length=100)
    service=models.CharField(null=True, blank=True, max_length=100)
    tag=models.CharField(null=True, blank=True, max_length=100)
    quantity = models.IntegerField(blank=True, )
    price = models.FloatField(null=True)
    totalPrice = models.FloatField(null=True)

    picture = models.FileField(upload_to="./static/product_image/", null=True, blank=True)



    discount=models.FloatField(default=False,blank=True,null=True)

    best_selling=models.BooleanField(default=False,null=True)

    limited_offer=models.BooleanField(default=False,null=True)

    # pet_type=models.CharField(blank=True, max_length=10, default=None,null=True)
    #
    # categoury=models.CharField(null=True, blank=True, max_length=100)

    related_products=models.CharField(null=True, blank=True, max_length=100)
    def __str__(self):
        return self.name


class productImage(models.Model):
    product = models.ForeignKey(product, default=None, on_delete=models.CASCADE)
    images = models.FileField(upload_to='images/')

    def __str__(self):
        return self.product.name