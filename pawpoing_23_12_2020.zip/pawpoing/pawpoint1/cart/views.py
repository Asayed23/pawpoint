from django.shortcuts import render,get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import cart,favourite,cartitem
from products.models import product
from django.core import serializers
from django.http import JsonResponse
from django.forms.models import model_to_dict
import json
# Create your views here.
class cart_details(APIView):
    # permission_classes = ()  # <-- And here

    def get(self, request,pk=None, *args, **kwargs):
        # products
        # queryset=cart.objects.filter(pk=pk).values()
        # print(queryset)
        # print(cartitem.objects.filter(CartId=pk).values())

        queryset2 = cartitem.objects.filter(CartId=pk).values()

        dict1 = {'cartid': pk, 'cartdata': list(queryset2.values())}
        for item in cartitem.objects.filter(CartId=pk):
            # print(item)
            print(type(product.objects.filter(id=item.productid.id)))
            # print(dict21)
            dict1.update({('productid_'+str(item.productid.id)): list(product.objects.filter(id=item.productid.id).values())})
            # dict1.update(dict11)
        # print(cartitem.objects.filter(CartId=pk).productid(id=1).values())

        return Response(dict1)

    def put(self, request,pk=None, *args, **kwargs):
        print(request.data)
        products=request.data['products']
        price= request.data['price']
        quantity = request.data['quantity']
        print(product.objects.filter(id=products))
        # # c1=cart(pk=pk)
        # ci1=cartitem()
        # ci1.quantity=quantity
        # ci1.price=price
        # ci1.CartId=pk
        # ci1.save()

        print(cartitem.objects.filter(CartId=pk,productid=products).exists())

        # productobj = get_object_or_404(product, id=products)
        if cartitem.objects.filter(CartId=pk,productid=products).exists():
            print("Deleted")
            cartitem.objects.filter(CartId=pk,productid=products).delete()
        else:
            # c1.cart.add(productobj.id)
            productobj = get_object_or_404(product, id=products)
            cartobj = get_object_or_404(cart, id=pk)
            ci1 = cartitem()
            ci1.quantity = quantity
            ci1.price = price
            ci1.CartId = cartobj
            ci1.productid=productobj
            ci1.save()
        queryset2 = cartitem.objects.filter(CartId=pk).values()

        dict2={'cartid':pk,'cartdata': list(queryset2.values())}
        for item in cartitem.objects.filter(CartId=pk):

            print(type(product.objects.filter(id=item.productid.id)))
            print('ho')
            dict2.update({('productid_'+str(item.productid.id)): list(product.objects.filter(id=item.productid.id).values())})
            # dict2.update(dict(product.objects.filter(id=item.productid.id).values()))
        # print(cartitem.objects.filter(CartId=pk).productid(id=1).values())
        # queryset2=dict| queryset2
        # print(queryset2.values())
        # dict2={'cartid':pk,'cartdata': list(queryset2.values())}
        print(dict2)
        print("hello")
        return Response(dict2)




class favourite_details(APIView):


    def get(self, request,pk=None, *args, **kwargs):
        # products
        queryset=favourite.objects.filter(pk=pk).values()
        # print(queryset)
        print(favourite.objects.get(pk=pk).favourite.all())
        queryset2=favourite.objects.get(pk=pk).favourite.all().values()
        print(queryset2)
        # assuming obj is a model instance
        # SomeModel_json = serializers.serialize("json", product.objects.filter(pk=pk))
        # struct = json.loads(SomeModel_json)

        return Response(queryset2)

    def put(self, request,pk=None, *args, **kwargs):
        print(request.data)
        products=request.data['products']
        c1=favourite(pk=pk)

        print(favourite.objects.get(pk=pk).favourite.filter(id=products).exists())
        # if products in product_ids.id:
        #     print("yes")
        productobj = get_object_or_404(product, id=products)
        if favourite.objects.get(pk=pk).favourite.filter(id=products).exists():
            c1.favourite.remove(productobj.id)
        else:
            c1.favourite.add(productobj.id)

        print(c1)
        productobj = get_object_or_404(product, id=products)
        # productobj
        # cart.cart.create(productobj)
        # print(cart.objects.get(pk=pk).cart.update(id=3))
        for obj in products:
            print(obj)
        # queryset = cart.objects.filter(pk=pk).values()
        # cart.objects.filter(Id="cartId")
        # "products"
        queryset2 = favourite.objects.get(pk=pk).favourite.all().values()

        return Response(queryset2)



