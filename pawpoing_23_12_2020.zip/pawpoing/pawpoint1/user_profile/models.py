from django.db import models
from django.contrib.auth.models import User
from cart.models import cart,favourite
# Create your views here.
class UserProfile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    full_name = models.CharField(null=True, blank=False, max_length=100)
    phone_number = models.IntegerField(blank=False, unique=True)
    admin = models.CharField(null=True, blank=False, max_length=100)  # admin
    address1=models.CharField(null=True, blank=False, max_length=100)
    address2 = models.CharField(null=True, blank=False, max_length=100)
    CartId = models.ForeignKey(cart, on_delete=models.CASCADE,null=True)


    favouriteid = models.ForeignKey(favourite, on_delete=models.CASCADE,null=True)


