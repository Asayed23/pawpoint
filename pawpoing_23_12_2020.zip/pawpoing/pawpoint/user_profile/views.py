from django.shortcuts import render
from rest_framework import generics, permissions
from rest_framework.response import Response
from knox.models import AuthToken
from .serializers import UserSerializer, RegisterSerializer
from .models import UserProfile
import base64
from django.core.files.base import ContentFile
from django.contrib.auth.models import User
from rest_framework import status

class RegisterAPI(generics.GenericAPIView):
    serializer_class = RegisterSerializer

    http_method_names = ['get', 'post', 'head', 'put']
    serializer_class = RegisterSerializer

    def get(self, request, *args, **kwargs):
        return Response({

        })

    def post(self, request, *args, **kwargs):

        if 'email' in request.data and User.objects.filter(

                email=request.data['email']).exists():

            return Response({"errorCode": 6001}, status=status.HTTP_400_BAD_REQUEST)

        if 'username' in request.data and  User.objects.filter(

                username=request.data['username']).exists():

            return Response({"errorCode": 6001}, status=status.HTTP_400_BAD_REQUEST)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user_profile = UserProfile()

        if 'phone_number' in request.data and not UserProfile.objects.filter(
                                                    phone_number=request.data['phone_number']).exists():



            user = serializer.save()
            print("hello")
            user_profile.user = user
            user_profile.phone_number = request.data['phone_number']
            user_profile.full_name = request.data['full_name']

            # home_location
            user_profile.address = request.data['address']
            user_profile.admin = request.data['admin']
            user_profile.save()
            user_response=UserSerializer(user, context=self.get_serializer_context()).data
            user_profile_response=UserProfile.objects.get(user=user_response['id'])
            print(user_profile_response)
            return Response({
                "id": user_response['id'],
                "username": user_response['username'],
                "email": user_response['email'],

                "address": user_profile_response.address,
                "phone_number": user_profile_response.phone_number,
                "full_name": user_profile_response.full_name,

                "admin": user_profile_response.admin,
                "token": AuthToken.objects.create(user)[1],
            })


        else:
            #phone number exist
            return Response({"errorCode": 6002}, status=status.HTTP_400_BAD_REQUEST)






        return Response({"errorCode":6003}, status=status.HTTP_400_BAD_REQUEST)




from django.contrib.auth import login,authenticate

from rest_framework import permissions
from rest_framework.authtoken.serializers import AuthTokenSerializer
from knox.views import LoginView as KnoxLoginView
from django.contrib.auth import get_user_model

class LoginAPI(KnoxLoginView):
    permission_classes = (permissions.AllowAny,)

    def post(self, request, format=None):
        serializer = AuthTokenSerializer(data=request.data)
        print(serializer)

        if 'password' in request.data and 'username' in request.data:
            user1 = authenticate(request, username=request.data['username'], password=request.data['password'])
        else:
            return Response({"errorCode": 401}, status=status.HTTP_401_UNAUTHORIZED)
        if user1 is not None:
            serializer.is_valid(raise_exception=True)

            user = serializer.validated_data['user']

            login(request, user)
            User = get_user_model()
            user_response=User.objects.filter(username=request.data['username'])
            print(user_response)
            user_profile_response = UserProfile.objects.get(user=request.user.id)
            return Response({
                "id": request.user.id,
                "username": request.user.username,
                "email": request.user.email,

                "address": user_profile_response.address,
                "phone_number": user_profile_response.phone_number,
                "full_name": user_profile_response.full_name,

                "admin": user_profile_response.admin,

                "token": AuthToken.objects.create(user)[1],
            })
        else:
            return Response({"errorCode": 6000}, status=status.HTTP_400_BAD_REQUEST)

        return super(LoginAPI, self).post(request, format=None)
