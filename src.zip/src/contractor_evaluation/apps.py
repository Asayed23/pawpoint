from django.apps import AppConfig


class ContractorEvaluationConfig(AppConfig):
    name = 'contractor_evaluation'
