from django.apps import AppConfig


class ServantAppConfig(AppConfig):
    name = 'servant_app'
