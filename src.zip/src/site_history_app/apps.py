from django.apps import AppConfig


class SiteHistoryAppConfig(AppConfig):
    name = 'site_history_app'
