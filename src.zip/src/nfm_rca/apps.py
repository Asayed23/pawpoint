from django.apps import AppConfig


class NfmRcaConfig(AppConfig):
    name = 'nfm_rca'
