from django.apps import AppConfig


class TechnicalPlanConfig(AppConfig):
    name = 'technical_plan'
