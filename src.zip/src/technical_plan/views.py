from django.shortcuts import render
from .models import tp_name,tp_details

# Create your views here.
