from django.contrib import admin
from .models import tp_name,tp_details
# Register your models here.
admin.site.register(tp_name)
admin.site.register(tp_details)