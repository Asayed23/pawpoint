from django.apps import AppConfig


class PkiInteractionAppConfig(AppConfig):
    name = 'pki_interaction_app'
