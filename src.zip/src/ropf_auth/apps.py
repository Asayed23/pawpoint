from django.apps import AppConfig


class RopfAuthConfig(AppConfig):
    name = 'ropf_auth'
