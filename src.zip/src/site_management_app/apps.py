from django.apps import AppConfig


class SiteManagementAppConfig(AppConfig):
    name = 'site_management_app'
