from django.apps import AppConfig


class CivilTechnicalOfficeConfig(AppConfig):
    name = 'civil_technical_office'
